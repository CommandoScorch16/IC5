#include "FunnyFacts.h"

int main ()
{

    /* Print sentence */
    Subject ();
    Verb ();
    Object ();

    return 0;

};

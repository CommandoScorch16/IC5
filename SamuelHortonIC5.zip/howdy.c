#include<stdio.h>

main()
{

int val = 2;

printf(“Hello World%d”,val);


}
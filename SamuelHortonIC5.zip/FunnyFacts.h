/* FunnyFacts Interface*/

/* Print the sentence Subject */
int Subject();

/* Print the sentence Verb */
int Verb();

/* Print the sentence Object */
int Object();

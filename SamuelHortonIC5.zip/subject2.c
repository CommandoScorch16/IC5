#include <stdio.h>
#include "FunnyFacts.h"

int Subject ()
{
    printf ("The national bird");
    return 0;
};

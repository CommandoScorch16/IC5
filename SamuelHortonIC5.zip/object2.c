#include <stdio.h>
#include "FunnyFacts.h"

int Object ()
{
    printf ("the bald eagle.\n");
    return 0;
};

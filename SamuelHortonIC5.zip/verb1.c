#include <stdio.h>
#include "FunnyFacts.h"

int Verb ()
{
    printf  (" is not ");
    return 0;
};

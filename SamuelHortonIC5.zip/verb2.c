#include <stdio.h>
#include "FunnyFacts.h"

int Verb ()
{
    printf  (" is ");
    return 0;
};

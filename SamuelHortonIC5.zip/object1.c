#include <stdio.h>
#include "FunnyFacts.h"

int Object ()
{
    printf ("the cornflower.\n");
    return 0;
};

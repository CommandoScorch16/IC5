#include <stdio.h>
#include "FunnyFacts.h"

int Subject ()
{
    printf ("The state flower");
    return 0;
};

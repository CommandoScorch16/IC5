CU-CSCI3308-MakePractice
===========================

Assignment to practice the use of GNU Make

By:  
Andy Sayler  
Judy Stafford  
Univerity of Colorado  
CSCI 3308  
Summer 2014

Forked from:  
https://github.com/asayler/CU-CSCI3308-LibraryPractice
